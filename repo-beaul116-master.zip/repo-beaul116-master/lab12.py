import random, turtle, math
def rand_color():
    return random.choice(["red", "orange", "yellow",
                          "green", "blue", "purple"])
class Shape:
    def __init__(self, x=0, y=0, color=''):
        self.x = x
        self.y = y
        self.color = color
    def set_color(self,st):
        self.color = st
    def get_color(self):
        return self.color
    def __str__(self):
        loc = "loc:("+str(self.x)+", "+str(self.y)+"), "
        col = "color:"+self.color
        return loc + col
    def draw(self,t):
        t.setpos(self.x,self.y)

class Circle(Shape):
    def __init__(self, x=0, y=0, rad=0):
        Shape.__init__(self,x,y,rand_color())
        self.rad = rad
    def __str__(self):
        shape_str = Shape.__str__(self)
        return shape_str + ", rad:"+str(self.rad)
    def draw(self,t):
        t.penup()
        t.setpos(self.x,self.y-self.rad)
        t.pendown()
        t.fillcolor(self.color)
        t.begin_fill()
        t.circle(self.rad)
        t.end_fill()
    def is_in(self, x, y):
        if math.sqrt((x-self.x)**2 + (y-self.y)**2) <= self.rad:
            return True
        else:
            return False
        

class Rectangle(Shape):
    def __init__(self, x=0, y=0, width=0, height=0):
        Shape.__init__(self, x, y, rand_color())
        self.width = width
        self.height = height

    def __str__ (self):
        x = Shape.__str__(self)
        return x + ', w:' + str(self.width) + ', h:' + str(self.height)

    def draw(self, t):
        t.penup()
        t.setpos(self.x,self.y)
        t.pendown()
        t.fillcolor(self.color)
        t.begin_fill()
        t.forward(self.width)
        t.left(90)
        t.forward(self.height)
        t.left(90)
        t.forward(self.width)
        t.left(90)
        t.forward(self.height)
        t.left(90)
        t.end_fill()
        
    def is_in(self, x, y):
        if self.x <= x <= self.x + self.width:
            if self.y <= y <= self.y + self.height:
                return True
        return False
        
        

class Display:
    def __init__(self):
        self.t = turtle.Turtle()
        self.x = turtle.Turtle()
        self.x.shape("turtle")
        self.x.setpos(0,0)
        self.sc = self.t.getscreen()
        self.elements = []
        self.t.speed(0)
        self.sc.delay(0)
        self.t.ht()
        self.sc.onclick(self.mouse_event)
        self.sc.onkeypress(self.move_up, 'Up')
        self.sc.onkeypress(self.move_right, 'Right')
        self.sc.onkeypress(self.move_down, 'Down')
        self.sc.onkeypress(self.move_left, 'Left')
        self.sc.listen()
        

    def mouse_event(self,x,y):
            random_num = random.randint(1,2)
            random_check = True
            for i in self.elements:
                if i.is_in(x,y):
                    self.remove(i)
                    random_check = False
                    break
            if random_check == True:
                if random_num == 1:
                    new_circ = Circle(x,y,random.randint(10,50))
                elif random_num == 2:
                    new_circ = Rectangle(x,y,random.randint(10,50),random.randint(10,50))
                self.elements.append(new_circ)
            
                new_circ.draw(self.t)

    def remove(self, target):
        self.elements.remove(target)
        self.t.clear()
        for i in self.elements:
            i.draw(self.t)


    def move_up(self):
        self.x.setheading(90)
        self.x.forward(10)
        self.feast()

    def move_right(self):
        self.x.setheading(0)
        self.x.forward(10)
        self.feast()

    def move_left(self):
        self.x.setheading(180)
        self.x.forward(10)
        self.feast()

    def move_down(self):
        self.x.setheading(270)
        self.x.forward(10)
        self.feast()

    def feast(self):
        for i in self.elements:
            if i.is_in(self.x.xcor(), self.x.ycor()):
                self.remove(i)
                self.x.color(i.color)
                self.x.shapesize(self.x.shapesize()[0]*1.2)
                self.x.pensize(self.x.pensize()*1.2)




















    
