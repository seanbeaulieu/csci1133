#==========================================
# Purpose: class of a complex number
# Input Parameter(s): constructor with real number and imaginary
# Return Value(s): none
#==========================================



class Complex:
    def __init__(self, real_num, real_imag):
        self.real = real_num
        self.imag = real_imag

    def get_real(self):
        return self.real

    def get_imag(self):
        return self.imag

    def set_real(self, new_real):
        self.real = new_real

    def set_imag(self, new_imag):
        self.imag = new_imag

    def __str__(self):
        return str(self.real) + " + " + str(self.imag) + 'i'

#==========================================
# Purpose: multiply two imaginary nunbers
# Input Parameter(s): self, other, two imaginary numbers
# Return Value(s): returns a complex class 
#==========================================

    def __mul__(self, other):
        real_num = self.real * other.real - self.imag * other.imag
        real_imag = self.real * other.imag + self.imag * other.real
        a = Complex(real_num, real_imag)
        return a

#==========================================
# Purpose: add two imaginary numberes
# Input Parameter(s): self, other, two imaginary numbers
# Return Value(s): returns a complex class
#==========================================

    def __add__(self, other):
        real_num = self.real + other.real
        real_imag = self.imag + other.imag
        a = Complex(real_num, real_imag)
        return a

#==========================================
# Purpose: tells if two imaginary numbers are equal to eachother 
# Input Parameter(s): self, other, two imaginary numbers
# Return Value(s): boolean value True or False
#==========================================

    def __eq__(self, other):
        if self.real == other.real and self.imag == other.imag:
            return True
        else:
            return False

#==========================================
# Purpose: Employee Object
# Input Parameter(s): l, line in the CSV file
# Return Value(s): None
#==========================================

class Employee:
    def __init__(self, l):
        emp_line = l.split(',')
        self.name = emp_line[0]
        self.position = emp_line[1]
        self.salary = float(emp_line[2])
        self.seniority = float(emp_line[3])
        self.value = float(emp_line[4])

    def __str__(self):
        return str(self.name) + ", " + str(self.position)

    def net_value(self):
        return self.value - self.salary
#==========================================
# Purpose: determines the lower net value
# Input Parameter(s): self, employee, two employee objects
# Return Value(s): True or False
#==========================================
    def __lt__(self, emp):
        if self.net_value() < emp.net_value():
            return True
        elif self.net_value() >= emp.net_value():
            return False

#==========================================
# Purpose: Branch class
# Input Parameter(s): fname, a CSV file
# Return Value(s): none
#==========================================

class Branch:
    def __init__(self, fname):
        fp = open(fname)
        list_emp = []
        for line in fp:
            l = line.split(',')
            if l[0] == 'Location':
                self.location = l[1]
            elif l[0] == 'Upkeep':
                self.upkeep = float(l[1])
            elif l[0] != 'Name':
                list_emp.append(Employee(line))
        self.team = list_emp

#==========================================
# Purpose: prints out the branch and the employees
# Input Parameter(s): self
# Return Value(s): string containing the branch and all the employees
#==========================================

    def __str__(self):
        a = self.location + '\n'
        b = ''
        for emp in self.team:
            b += str(emp) + '\n'
        return a + b

#==========================================
# Purpose: returns the profit of a branch
# Input Parameter(s): self
# Return Value(s): returns all the employees values minus the upkeep
#==========================================

    def profit(self):
        a = 0
        for emp in self.team:
            a += emp.net_value()
        return a - self.upkeep

#==========================================
# Purpose: determines the lower profit between two branches
# Input Parameter(s): self, other, another branch 
# Return Value(s): True or False
#==========================================

    def __lt__(self, other):
        if self.profit() < other.profit():
            return True
        elif self.profit() >= other.profit():
            return False

    def cut(self, num):
        self.team.sort()
        del self.team[:num]

#==========================================
# Purpose: Company class
# Input Parameter(s): name, branches, name is the name of the company and branches is a list of branches
# Return Value(s): none
#==========================================

class Company:
    def __init__(self, name, branches):
        self.name = name
        self.branches = branches

#==========================================
# Purpose: prints the company name and branches
# Input Parameter(s): self
# Return Value(s): string of company name plus branches 
#==========================================

    def __str__(self):
        a = self.name + '\n\n'
        b = ''
        for branch in self.branches:
            b += str(branch) + '\n'
        return a + b

#==========================================
# Purpose: cuts half of a branches lowest value employees
# Input Parameter(s): self
# Return Value(s): none
#==========================================

    def synergize(self):
        index = 0
        lowest_index = 0
        lowest = self.branches[0]
        for branch in self.branches:
            if branch.profit() < lowest.profit():
                lowest = branch
                lowest_index = index
            index += 1
        length = int(len(lowest.team) / 2)
        self.branches[lowest_index].cut(length)


 
            
            
        





















        


