import random
#==========================================
# Purpose: gets the first word of every sentence
# Input Parameter(s): fname, a file containing sentences
# Return Value(s): a list of every first word of each sentence
#==========================================

def first_words(fname):
    fp = open(fname)
    l1 = []
    for line in fp:
        a = line.split(' ')
        l1.append(a[0])    
    fp.close()
    return l1

#==========================================
# Purpose: gets a dictionary of every unique word with the keys as the words following
# Input Parameter(s): fname, a file containing strings
# Return Value(s): dict_unique, a dictionary 
#==========================================

def next_words(fname):
    fp = open(fname)
    dict_unique = {}
    text = fp.read()
    l1 = text.split('\n')
    text2 = ','.join(l1)
    text2 = text2.replace(',',' ')
    #print(text2)
    text3 = text2.split(' ')
    l2 = []
    for word in text3:
        index1 = 0
        for word2 in text3:
            if word == word2:
                index1 += 1
        if index1 == 1:
            l2.append(word)
    #print(l2)
    index2 = 0
    #print(text3)
    text4 = text3.copy()
    for word in text3:        
        if word in l2:
            text3[index2] = 'X'
        index2 += 1
    #print(text3)

    index_x = 0
    
    
    for x1 in range(len(text3)):
        value_list = []
        #print(range(len(text3))
        if text3[x1] == 'X':
            if x1 != (len(text3)):
                index_x = x1
                #print(index_x)
                if index_x + 1 != len(text3):
                    while text3[index_x + 1] != 'X':
                        temp = text3[index_x+1]
                        #print(text3[index_x+1])
                        value_list.append(temp)
                        #print(value_list)
                        if index_x != (len(text3) - 2):
                            index_x += 1
                        elif index_x == (len(text3) - 2):
                            index_x += 1
                            break
            dict_unique[text4[x1]] = value_list                
                   
    #print(text4)            
    return dict_unique              
    fp.close()
    

#==========================================
# Purpose: make a fanfiction
# Input Parameter(s): fname, a file containing strings 
# Return Value(s): none
#==========================================

def fanfic(fname):
    fp = open(fname)
    firstwords = first_words(fname)
    nextwords = next_words(fname)
    for x in range(10):
        first_word = random.choice(firstwords)
        word_chosen = ''
        while word_chosen != '.':
            word_chosen = random.choice(list(nextwords))
            first_word += ' ' + word_chosen
            try:
                word_chosen = random.choice(nextwords[word_chosen])
                first_word += ' ' + word_chosen
            except IndexError:
                word_chosen = random.choice(list(nextwords))
                first_word += ' ' + word_chosen
        print(first_word)
            
            
#==========================================
# Purpose: return the total of all .txt files in a dictionary
# Input Parameter(s): directory,  a directory containing more directories or files
# Return Value(s): total, the total value of all .txt files
#==========================================

#substr = a_string[-4:]  

def total_txt_size(directory):
    total = 0    
    for keys in directory:
            #print(keys)
            substr_keys = keys[-4:]
            if substr_keys == '.txt':
                total += directory[keys]
                #print("substring")
                #print(total)
            elif type(directory[keys]) == dict:
                #print("dict")
                total += total_txt_size(directory[keys])   
            else:
                #print("none")
                total += 0
            
    return total















