class Adventurer:

#==========================================
# Purpose: initalize adventurer class with values
# Input Parameter(s): self, name, level, strength, speed, power
# Return Value(s): none
#==========================================

    
    def __init__(self, name, level, strength, speed, power):
        self.name = str(name)
        self.level = int(level)
        self.strength = int(strength)
        self.speed = int(speed)
        self.power = int(power)
        self.HP = self.level * 6
        self.hidden = False

    def __repr__(self):
        return str(self.name) + ' - ' + 'HP: ' + str(self.HP)

#==========================================
# Purpose: attacks another character / object
# Input Parameter(s): self, target, two adventurer object
# Return Value(s): True or False
#==========================================

    def attack(self, target):
        if target.hidden == True:
            print(self.name + " can't see " + target.name)
        else:
            target.HP -= self.strength + 4
            x = int(self.strength) + 4
            print(str(self.name) + " attacks " + str(target.name) + " for " + str(x) + " damage")

#==========================================
# Purpose: Compares if one objects HP is higher or lower than the other
# Input Parameter(s): self, other, two adventurer objects
# Return Value(s): True or False
#==========================================

    def __lt__(self, other):
        if self.HP < other.HP:
            return True
        elif self.HP >= other.HP:
            return False


class Fighter(Adventurer):
    def __init__(self, name, level, strength, speed, power):
        #Adventurer.__init__(self, name, level, strength, speed, power)
        super().__init__(name, level, strength, speed, power)
        self.HP = self.level * 12

#==========================================
# Purpose: attacks another adventurer object
# Input Parameter(s): self, target, two adventurer objects
# Return Value(s): none
#==========================================

    def attack(self, target):
        if target.hidden == True:
            print(self.name + " can't see " + target.name)
        else:
            target.HP -= 2 * self.strength + 6
            x = 2 * int(self.strength) + 6 
            print(str(self.name) + " attacks " + str(target.name) + " for " + str(x) + " damage")


class Thief(Adventurer):
    def __init__(self, name, level, strength, speed, power):
        super().__init__(name, level, strength, speed, power)
        self.HP = self.level * 8
        self.hidden = True

#==========================================
# Purpose: sneak attack / attacks another adventurer
# Input Parameter(s): self, target, two adventuer objects
# Return Value(s): none
#==========================================

    def attack(self, target):
        if self.hidden == False:
            super().attack(target)
##            if target.hidden == True:
##                print(self.name + " can't see " + target.name)
##            else:
##                target.HP -= 2 * self.strength + 6
##                x = 2 * int(self.strength) + 6 
##                print(str(self.name) + " attacks " + str(target.name) + " for " + str(x) + " damage")
        elif self.hidden == True:
            if self.hidden == True and target.hidden == True:
                if self.speed < target.speed:
                    print(self.name + " can't see " + target.name)
            else:
                target.HP -= (self.speed + self.level) * 5
                x = (self.speed + self.level) * 5
                target.hidden = False
                self.hidden = False
                print(str(self.name) + " sneak attacks " + str(target.name) + " for " + str(x) + " damage")
                    

class Wizard(Adventurer):
    def __init__(self, name, level, strength, speed, power):
        super().__init__(name, level, strength, speed, power)
        self.HP = self.level * 6
        self.fireballs_left = power

#==========================================
# Purpose: attacks another adventurer with fireballs
# Input Parameter(s): self, target, two adventurer objects
# Return Value(s): none
#==========================================

    def attack(self, target):
        if self.fireballs_left == 0:
            super().attack(target)
        else:
            target.hidden = False
            target.HP -= self.level * 3
            x = self.level * 3
            self.fireballs_left -= 1
            print(str(self.name) + " casts fireball on " + str(target.name) + " for " + str(x) + " damage")


#==========================================
# Purpose: pits two adventurers against eachother until one hp drops below 0
# Input Parameter(s): adv1 and adv2, two adventurer objects
# Return Value(s): True or False
#==========================================


def duel(adv1, adv2):
    while adv1.HP > 0 and adv2.HP > 0:
        if adv1 == adv2:
            print(adv1)
            print(adv2)
            print("Everybody loses!")
            return False
        if adv1.HP < 0 and adv2.HP < 0:
            print(adv1)
            print(adv2)
            print("Everybody loses!")
            return False
        print(adv1)
        print(adv2)
        adv1.attack(adv2)
        if adv2.HP <= 0:
            print(adv1)
            print(adv2)
            print(str(adv1.name) + " wins!")  
            return True
        
        adv2.attack(adv1)
        if adv1.HP <= 0:
            print(adv1)
            print(adv2)
            print(str(adv2.name) + " wins!")
            return False
            
#==========================================
# Purpose: runs a tournament and automates duel() until 1 is left
# Input Parameter(s): adv_list, list of adventurers
# Return Value(s): adv_list[0], the only object left
#==========================================


def tournament(adv_list):
    if len(adv_list) == 0:
        return None
    while len(adv_list) > 1:
        adv_list.sort()
        #print(adv_list)
        highest_hp = adv_list[len(adv_list) - 1]
        second_hp = adv_list[len(adv_list) - 2]
        winner = duel(second_hp, highest_hp)
        if winner == True:
            adv_list.remove(highest_hp)
        elif winner == False:
            adv_list.remove(second_hp)
    return adv_list[0]
        



    
        
        
