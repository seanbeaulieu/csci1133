import turtle

def draw_square(sidelength):
    turtle.forward(sidelength)
    turtle.left(90)
    turtle.forward(sidelength)
    turtle.left(90)
    turtle.forward(sidelength)
    turtle.left(90)
    turtle.forward(sidelength)
    turtle.left(120)


draw_square(100)
draw_square(200)
draw_square(300)
draw_square(400)
