def print_reverse(num):
    thousand = num // 1000
    hundo = num // 100 % 10
    ten = num // 10 % 10
    single = num // 1 % 10

    new = single * 1000 + ten * 100 + hundo * 10 + thousand
    print(new)

print_reverse(1234)

def return_reverse(num):
    thousand = num // 1000
    hundo = num // 100 % 10
    ten = num // 10 % 10
    single = num // 1 % 10

    new = single * 1000 + ten * 100 + hundo * 10 + thousand
    return new
