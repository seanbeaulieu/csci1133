Grade: 30/40  
Comments: -10 edge detect not attempted 