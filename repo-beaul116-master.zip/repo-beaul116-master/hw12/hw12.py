import tkinter as tk
import random




#FIRST: Implement and test your Pokemon class below
class Pokemon:
    #print("Implement this and then remove this print statement")
    def __init__(self, l1):
        
        l = l1.split(',')
        self.dex_num = l[0]
        self.name = l[1]
        self.catch_rate = l[2]
        x = l[3].replace('\n', '')
        self.speed = x

    def __str__(self):
        return str(self.name)
    


#NEXT: Complete the class definition provided below
class SafariSimulator(tk.Frame):
    def __init__(self, master=None):
        #print("In SafariSimulator init")
        #Read in the data file from pokedex.csv at some point here
        #It's up to you how you store and handle the data 
        #(e.g., list, dictionary, etc.),
        #but you must use your Pokemon class in some capacity
        self.pokelist = []
        fp = open('pokedex.csv')
        fp.readline()
        #a = fp.readline()
        #a1 = a.split(',')
        #print(a1)
        for line in fp:
            self.pokelist.append(Pokemon(line))
        self.balls_left = 30
        self.caught = []
        pp = '1,M,0,0'
        self.current_pokemon = Pokemon(pp)
       
        
            
            
        
        #Initialize any instance variables you want to keep track of

        #DO NOT MODIFY: These lines set window parameters and create widgets
        tk.Frame.__init__(self, master)
        master.minsize(width=275, height=350)
        master.maxsize(width=275, height=350)
        master.title("Safari Zone Simulator")
        self.pack()
        self.createWidgets()

        #Call nextPokemon() method here to initialize your first random pokemon
        self.nextPokemon()

    def createWidgets(self):
        #print("In createWidgets")
        #See the image in the instructions for the general layout required
        #"Run Away" button has been completed for you as an example:
        self.runButton = tk.Button(self)
        self.runButton["text"] = "Run Away"
        self.runButton["command"] = self.nextPokemon
        self.runButton.pack()
        
        #You need to create an additional "throwButton"

        self.throwButton = tk.Button(self)
        self.throwButton['text'] = 'Throw Safari Ball (' + str(self.balls_left) + ' left)'
        self.throwButton['command'] = self.throwBall
        self.throwButton.pack()
        

        #A label for status messages has been completed for you as an example:
        self.messageLabel = tk.Label(bg="grey")
        self.messageLabel.pack(fill="x", padx=5, pady=5)
       

        #You need to create two additional labels:

        #Complete and pack the pokemonImageLabel here.
        
        self.pokemonImageLabel = tk.Label(bg="grey")
        self.pokemonImageLabel.pack(fill="x", padx=5, pady=5)
        
        
        #Complete and pack the catchProbLabel here.
        
        self.catchProbLabel = tk.Label(bg="grey")
        self.catchProbLabel.pack(fill="x", padx=5, pady=5)
        

        

        

    def nextPokemon(self):
        #print("In nextPokemon")

        rand_pokemon = random.choice(self.pokelist)
        self.current_pokemon = rand_pokemon
        #print(rand_pokemon)
        #print(rand_pokemon.catch_rate)
        z = int(rand_pokemon.catch_rate) + 1
        self.messageLabel['text'] = 'You encounter a wild ' + rand_pokemon.name
        xy = ((min(z, 151) / 449.5))
        xy *= 100
        xy = int(xy)
        self.catchProbLabel['text'] = 'Your chance of catching it is ' + str(xy) + '%!'
        p = 'sprites/' + str(rand_pokemon.dex_num) + '.gif'
        #print(p)
        self.photo = tk.PhotoImage(file=p)
        self.pokemonImageLabel['image'] = self.photo
        
        
        
        #This method must:
            #Choose a random pokemon
            #Get the info for the appropriate pokemon
            #Ensure text in messageLabel and catchProbLabel matches the pokemon
            #Change the pokemonImageLabel to show the right pokemon

        #Hint: to see how to create an image, look at the documentation 
        #for the PhotoImage/Label classes in tkinter.
        
        #Once you generate a PhotoImage object, it can be displayed 
        #by setting self.pokemonImageLabel["image"] to it
        
        #Note: the PhotoImage object MUST be stored as an instance
        #variable for some object (you can just set it to self.photo).
        #Not doing this will, for weird memory reasons, cause the image 
        #to not be displayed.
        
    def throwBall(self):
        #print("In throwBall")
        if self.balls_left == 1:
            self.endAdventure()
        self.balls_left -= 1
        self.throwButton['text'] = 'Throw Safari Ball (' + str(self.balls_left) + ' left)'
        
        z = int(self.current_pokemon.catch_rate) + 1
        
        xy = ((min(z, 151) / 449.5))
        
        
        
        rand_num = random.random()
        #print(rand_num)
        #print(xy)
        if rand_num < xy:
            self.caught.append(self.current_pokemon)
            self.nextPokemon()
        else:
            if self.balls_left != 1:
                self.messageLabel['text'] = 'Aargh! It escaped!'
        
        #This method must:

            #Decrement the number of balls remaining
            #Try to catch the pokemon
            #Check to see if endAdventure() should be called

        #To determine whether or not a pokemon is caught, generate a random
        #number between 0 and 1, using random.random().  If this number is
        #less than min((catchRate+1), 151) / 449.5, then it is caught. 
        #catchRate is the integer in the Catch Rate column in pokedex.csv, 
        #for whatever pokemon is being targetted.
        
        #Don't forget to update the throwButton's text to reflect one 
        #less Safari Ball (even if the pokemon is not caught, it still 
        #wastes a ball).
        
        #If the pokemon is not caught, you must change the messageLabel
        #text to "Aargh! It escaped!"
        
        #Don't forget to call nextPokemon to generate a new pokemon 
        #if this one is caught.
        
    def endAdventure(self):
        #print("In endAdventure")
        self.runButton.pack_forget()
        self.throwButton.pack_forget()
        self.messageLabel.pack_forget()
        self.pokemonImageLabel.pack_forget()
        self.catchProbLabel.pack_forget()

        self.adventureComplete = tk.Label(bg="grey")
        self.adventureComplete.pack(fill="x", padx=5, pady=5)
        self.adventureComplete['text'] = 'You\'re all out of balls, hope you had fun!'

        self.pokelist = tk.Label(bg="grey")
        self.pokelist.pack(fill="x", padx=5, pady=5)
        st = 'You caught ' + str(len(self.caught)) + ' Pokemon: \n'
        for x in self.caught:
            st += str(x) + '\n'
            
        self.pokelist['text'] = st
        
        #This method must: 

            #Display adventure completion message
            #List captured pokemon

        #Hint: to remove a widget from the layout, you can call the 
        #pack_forget() method.
        
        #For example, self.pokemonImageLabel.pack_forget() removes 
        #the pokemon image.




#DO NOT MODIFY: These lines start your app
app = SafariSimulator(tk.Tk())
app.mainloop()
