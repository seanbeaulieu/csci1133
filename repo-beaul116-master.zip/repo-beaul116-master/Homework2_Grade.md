Grade: 39/40  
Comments: Problem C: -1 lack of documentation for helper functions