Grade: 36.0/40  
Comments: -4 not writing to file in hax