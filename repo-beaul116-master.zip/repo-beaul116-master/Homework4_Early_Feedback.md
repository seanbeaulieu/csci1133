### Early Feedback for Homework 4 (THIS IS NOT YOUR GRADE, the assignment isn't due yet)

These tests are run on Tuesday nights around 11:55 PM, so if you didn't submit before then you can ignore this document

Passing these tests is not a guarantee of a perfect homework score: the tests do not check everything that the TAs will.

Any questions/errors with the Automated Feedback should be reported to Nathan Taylor: taylo740@umn.edu

Run on October 02, 00:09:45 AM.

+ Fail: Change into directory "hw4".

     Directory "hw4" not found.

+ Skip: Check that file "hw4.py" exists.

  This test was not run because of an earlier failing test.

+ Skip: Check that Python file "hw4.py" only imports permitted modules.

  This test was not run because of an earlier failing test.

+ Skip: Check that a Python file "hw4.py" has no syntax errors.

  This test was not run because of an earlier failing test.

+ Skip: Writing encrypted5.txt into local directory  
File Contents:
```
402153397
iojzkpgqzcv{c{z{kicgmnd|teggoah|xe

```


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   find_password('encrypted5.txt') + 'o'
   ```
   matches the pattern `'mario'`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   count_primes(128374612, 128374711) + count_primes(1, 2)
   ```
   matches the pattern `9`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   population(900, 600, 300) + population(300, 600, 900)
   ```
   matches the pattern `165`.

   


  This test was not run because of an earlier failing test.

