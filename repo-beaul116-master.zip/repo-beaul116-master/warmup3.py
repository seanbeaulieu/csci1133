import turtle
import random

def roundit(pv):
    if (pv < 0):
        pv -= 0.5
        p = int(pv)
    elif (pv > 0):
        pv += 0.5
        p = int(pv)
    elif (pv == 0):
        p = 0
    print(p)

def draw_square(length):
    i = 0
    while i < 4:
        turtle.forward(length)
        turtle.right(90)
        i += 1

def draw_triangle(length):
    i = 0
    while i < 3:
        turtle.forward(length)
        turtle.right(120)
        i += 1
def draw_shape():
    turtle.speed(10)
    num = int(input("Enter the number of shapes: "))
    shape = str(input("Enter shape type (S or s for square, T or t for triangle): "))
    m = 0
    if (shape == 'S' or shape == 's'):
        while m < num:
            draw_square(100)
            turtle.right(360/num)
            m += 1
    elif (shape == 'T' or shape == 't'):
        while m < num:
            draw_triangle(100)
            turtle.right(360/num)
            m += 1
    else:
        print("Illegal shape type entered: " , shape)


def drunken_walk():
    turtle.speed(300)
    number = 0
    while ((turtle.xcor() < 300 or turtle.xcor() < -300) and (turtle.ycor() < 300 or turtle.ycor() < -300)):
        rando = random.randint(1,4)
        if (rando == 1):
            turtle.setheading(0)
            turtle.forward(30)
        elif (rando == 2):
            turtle.setheading(90)
            turtle.forward(30)
        elif (rando == 3):
            turtle.setheading(180)
            turtle.forward(30)
        elif (rando == 4):
            turtle.setheading(270)
            turtle.forward(30)
        number += 1
    turtle.write(number, font=("Arial", 32, "normal"))




