### Early Feedback for Homework 12 (THIS IS NOT YOUR GRADE, the assignment isn't due yet)

These tests are run on Monday and Tuesday nights around 12:55 PM, so if you didn't submit before then you can ignore this document

Note that due to the nature of Homework 12, the tests for this week are very minimal

Any questions/errors with the Automated Feedback should be reported to Nathan Taylor: taylo740@umn.edu

Run on December 17, 00:41:26 AM.

+ Pass: Change into directory "hw12".

+ Pass: Check that file "hw12.py" exists.

+ Pass: Secret Test

+ Pass: Check that a Python file "hw12.py" has no syntax errors.

    Python file "hw12.py" has no syntax errors.



