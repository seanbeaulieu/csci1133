### Early Feedback for Homework 5 (THIS IS NOT YOUR GRADE, the assignment isn't due yet)

These tests are run on Monday and Tuesday nights around 11:55 PM, so if you didn't submit before then you can ignore this document

Passing these tests is not a guarantee of a perfect homework score: the tests do not check everything that the TAs will.

Any questions/errors with the Automated Feedback should be reported to Nathan Taylor: taylo750@umn.edu

Run on October 09, 01:03:17 AM.

+ Fail: Change into directory "hw5".

     Directory "hw5" not found.

+ Skip: Check that file "hw5.py" exists.

  This test was not run because of an earlier failing test.

+ Skip: Check that a Python file "hw5.py" has no syntax errors.

  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   wizards(['elphaba','glinda','nessa'],['boq','elphaba','fiyero','glinda'],['elphaba','fiyero','glinda'])+[]
   ```
   matches the pattern `['elphaba','glinda']`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   open_slots(['-', '-', 'O', 'X', 'O', 'X', '-', '-', 'X'])+[]
   ```
   matches the pattern `[0, 1, 6, 7]`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   winner(['-', 'O', 'X', '-', '-', 'X', '-', 'O', 'X'])+''
   ```
   matches the pattern `'X'`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   tic_tac_toe() in ['X', 'O', 'D']
   ```
   matches the pattern `True`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   ([tic_tac_toe() for i in range(10000)]).count('X')
   ```
   is approximately `5849`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   ([tic_tac_toe() for i in range(10000)]).count('O')
   ```
   is approximately `2882`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   play_games(100)
   ```
   matches the pattern `None`.

   


  This test was not run because of an earlier failing test.

