Grade: 38.0/40  
Comments: should only check divisors up to the square root of n in problem B