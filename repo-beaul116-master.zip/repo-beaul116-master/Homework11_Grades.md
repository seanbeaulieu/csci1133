Grade: 37.0/40  
Comments: -1: incorrect attack in Thief, -2: infinite loop in tournament.