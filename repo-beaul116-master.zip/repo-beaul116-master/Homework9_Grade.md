Grade: 38.5/40  
Comments: Value lists for each key in next_words output are incorrect