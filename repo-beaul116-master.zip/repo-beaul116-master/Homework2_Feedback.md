### Early Feedback for Homework 2 (THIS IS NOT YOUR GRADE, the assignment isn't due yet)

Passing these tests is not a guarantee of a perfect homework score: the tests do not check everything that the TAs will.

Any questions/errors with the Automated Feedback should be reported to Nathan Taylor: taylo740@umn.edu

Run on September 18, 00:20:35 AM.

+ Fail: Change into directory "hw2".

     Directory "hw2" not found.

+ Skip: Check that file "hw2.py" exists.

  This test was not run because of an earlier failing test.

+ Skip: Check that Python file "hw2.py" only imports permitted modules.

  This test was not run because of an earlier failing test.

+ Skip: Check that a Python file "hw2.py" has no syntax errors.

  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   length_contract(1000, 298765432)
   ```
   is approximately `90.62846265282911`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   bessel_run(295000000)
   ```
   is approximately `7.232249748056239`.

   


  This test was not run because of an earlier failing test.

+ Skip: 
Check that the result of evaluating
   ```
   print_100()
   ```
   is 'Who needs loops?' printed 100 times.

   


  This test was not run because of an earlier failing test.

